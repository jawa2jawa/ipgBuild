package org.ipg.nms;

public class FTPUtil {

	public String uploadFile() {
		System.out.println("It is from file uploading..");
		return "Hello It is Ark";
	}
}
