package com.ipg.horizon.nms.config.dispach;

import com.ipg.horizon.nms.config.commands.AbstractRPC;
import com.ipg.horizon.nms.config.handler.CommandHandler;

public class CommandConsumer extends Thread {
	

	public CommandConsumer( ) {
	}

	public void run() { 
		while(true) {
			AbstractRPC cmd=null;
			try {
				cmd = CommandPool.getInstance().commands.take();
				String id=cmd.getMessageID();
				CommandHandler.getInstance().hadleCommand(id,cmd.toString());
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
