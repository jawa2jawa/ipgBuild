package com.ipg.horizon.nms.config.handler;

public class CommandResponse {
	String response = "";
	String type = "json";
	int messageID = 0;

	public int getMessageID() {
		return messageID;
	}

	public void setMessageID(int messageID) {
		this.messageID = messageID;
	}

	public CommandResponse(String response, String type) {
		this.response = response;
		this.type = type;
	}

	public CommandResponse(String response) {
		this.response = response;
	}

	public String toString() {
		StringBuilder buff = new StringBuilder();
		String result = "";
		if ("json".equalsIgnoreCase(type)) {

		}
		if ("xml".equalsIgnoreCase(type)) {

		}
		result = buff.toString();
		return result;
	}
}
