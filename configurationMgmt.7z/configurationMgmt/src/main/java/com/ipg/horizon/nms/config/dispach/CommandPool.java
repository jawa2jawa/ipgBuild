package com.ipg.horizon.nms.config.dispach;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;

import com.ipg.horizon.nms.config.commands.AbstractRPC;
import com.ipg.horizon.nms.config.handler.CommandResponse;
import com.ipg.horizon.nms.config.handler.ConnectionInfoLock;

public class CommandPool {
	private static CommandPool instance = new CommandPool();
	public LinkedBlockingQueue<AbstractRPC> commands = new LinkedBlockingQueue<AbstractRPC>();
	public LinkedBlockingQueue<CommandResponse> respons = new LinkedBlockingQueue<CommandResponse>();
	/**
	 * map between messageID and connection lock
	 */
	public Map<String, ConnectionInfoLock> synchMap = new HashMap<String, ConnectionInfoLock>();
	/**
	 * map between messageID and command response
	 */
	public Map<String, CommandResponse> responseMap = new HashMap<String, CommandResponse>();

	public void registerLock(String id, ConnectionInfoLock lock) {
		synchMap.put(id, lock);
	}

	private CommandPool() {

	}

	public static CommandPool getInstance() {
		return instance;
	}
}
