package com.ipg.horizon.nms.config.handler;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import com.ipg.horizon.nms.config.dispach.CommandPool;
import com.ipg.horizon.nms.config.netconf.NetconfSessionFactory;

/**
 * Device and CommandExecutor are in ONE-TO-ONE relation therefore many
 * commands(each in separate thread) to one Device are sharing single instance
 * of this class
 * 
 * @author samuel.a
 *
 */
public class CommandVisitor {
	ThreadPoolExecutor executor = null;
	NetconfSessionFactory netconfSessionFactory = null;

	public CommandVisitor(NetconfSessionFactory netconfSessionFactory) {
		this.netconfSessionFactory = netconfSessionFactory;
		/*
		 * Until number of Threads are less then 10,Thread pool creates new thread per
		 * each task
		 */
		int corePoolSize = 10;
		/*
		 * once the number of threads reaches to the 'corePoolSize=10' then task are
		 * added in to the blocking queue .once the queue reached to the queueSize=100
		 * then it created the Thread up to maximumPoolSize=20,once all 20 threads are
		 * busy and there is no place in Queue then Thread pool rejects the task
		 */
		int maximumPoolSize = 20;
		/*
		 * once the tasks are completing The thread will wait for keepAliveTime to get
		 * the next task
		 */
		long keepAliveTime = 1L;
		executor = new ThreadPoolExecutor(corePoolSize, maximumPoolSize, keepAliveTime, TimeUnit.MILLISECONDS,
				new LinkedBlockingQueue<Runnable>(100));

		executor.setRejectedExecutionHandler(
				new NetConfCommandRejectedExecutionHandler(new ThreadPoolExecutor(corePoolSize, maximumPoolSize,
						keepAliveTime, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<Runnable>(100))));
	}

	public String  submit() {
		String result = "";

		NetConfCommandCallable callable;
		try {
			callable = new NetConfCommandCallable(CommandPool.getInstance().commands.take());
			result = ((Future<String>) executor.submit(callable)).get();
		} catch (InterruptedException | ExecutionException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		CommandResponse response = new CommandResponse(result, "json");
		CommandPool.getInstance().respons.add(response);
		result=response.toString();
		return result;
	}

}
