package com.ipg.horizon.nms.config.connection;

import com.ipg.horizon.nms.config.connection.NetConfDeviceRegistryBuilder.NetConfDeviceRegistry;
import com.ipg.horizon.nms.config.netconf.NetconfSessionFactory;

public class NetconfAPI {
	NetconfSessionFactory netconfSessionFactory = null;

	public NetconfAPI(NetConfDeviceRegistry regestry) {
		// TODO Auto-generated constructor stub
		netconfSessionFactory = new NetconfSessionFactory(regestry);
	}

	public String execute(String cmd) {
		return netconfSessionFactory.getSession().execute(cmd);
	}

}
