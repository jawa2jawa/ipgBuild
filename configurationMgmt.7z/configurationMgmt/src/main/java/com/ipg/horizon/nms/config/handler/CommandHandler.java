package com.ipg.horizon.nms.config.handler;

import java.util.HashMap;
import java.util.Map;

import com.ipg.horizon.nms.config.commands.AbstractRPC;
import com.ipg.horizon.nms.config.commands.CommandFactory;
import com.ipg.horizon.nms.config.connection.NetConfDeviceRegistryBuilder;
import com.ipg.horizon.nms.config.dispach.CommandConsumer;
import com.ipg.horizon.nms.config.dispach.CommandProducer;
import com.ipg.horizon.nms.config.dispach.ResponseGatherer;
import com.ipg.horizon.nms.config.netconf.NetconfSessionFactory;

/**
 * It has to have all the device info and creates the
 * NetConfDeviceRegistryBuilder and creates the NetConfDeviceRegistry populate
 * the deviceConnectionPool for each device
 * 
 * @author samuel.a
 *
 */
public class CommandHandler {
	static private CommandHandler commandHandler=new CommandHandler();
	/**
	 * This map stores the ip address of device and corresponding executor
	 */
	Map<String, CommandVisitor> deviceConnectionPool = new HashMap<String, CommandVisitor>();

	CommandFactory commandFactory = null;
	NetconfSessionFactory netconfSessionFactory = null;

	private CommandHandler() {
		Thread commadConsumerThread=new CommandConsumer(); 
		commadConsumerThread.start();
		Thread responseGathererThread=new ResponseGatherer();
		responseGathererThread.start();
	}
	public static CommandHandler getInstance() {
		return commandHandler;
	}

	public void populateConnectionMap(String connectionDetails, Map<String, String> settings) {

	}

	public void hadleCommand(String deviceIP, String command) {
		
	}
	/**
	 * Each Thread executes it and it will not leads to any thread issues
	 * 
	 * @param deviceIP
	 * @param command
	 * @return
	 */
	public String addCommand(String deviceIP, String command) {
		NetConfDeviceRegistryBuilder netconfDeviceRegBuilder = new NetConfDeviceRegistryBuilder();
		Map<String, String> settings = new HashMap<String, String>();
		populateConnectionMap(deviceIP, settings);
		netconfSessionFactory = new NetconfSessionFactory(netconfDeviceRegBuilder.buildRegistery(settings));
		CommandVisitor commandVisitor=deviceConnectionPool.get(deviceIP);
		if (commandVisitor == null) {
			deviceIP = deviceIP.split("#")[0];
			/**
			 * It does't matter who requested first ,it is just to load the device details and set the executor
			 */
			deviceConnectionPool.put(deviceIP, new CommandVisitor(netconfSessionFactory));
		}
		commandFactory = new CommandFactory(netconfSessionFactory);
		AbstractRPC cmd = commandFactory.getCommand(command);
		cmd.visit(commandVisitor);
		CommandProducer cp=new CommandProducer();
		return cp.addCommand(cmd).toString();
	}
}
