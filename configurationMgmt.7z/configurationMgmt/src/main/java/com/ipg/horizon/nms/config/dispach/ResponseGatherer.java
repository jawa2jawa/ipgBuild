package com.ipg.horizon.nms.config.dispach;

import com.ipg.horizon.nms.config.handler.CommandResponse;

public class ResponseGatherer extends Thread {

	public ResponseGatherer() {
	}

	public void run() {
		while (true) {
			try {
				CommandResponse response = CommandPool.getInstance().respons.take();
				 CommandPool.getInstance().responseMap.put(response.getMessageID() + "", response);
				synchronized ( CommandPool.getInstance().synchMap.get(response.getMessageID() + "")) {
					notify();
				}
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
