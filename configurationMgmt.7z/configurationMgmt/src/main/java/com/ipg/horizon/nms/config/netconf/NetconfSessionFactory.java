package com.ipg.horizon.nms.config.netconf;

import com.ipg.horizon.nms.config.connection.NetConfDeviceRegistryBuilder.NetConfDeviceRegistry;

public class NetconfSessionFactory {
	NetconfSession session = null;

	public NetconfSession getSession() {
		return session;
	}

	public void setSession(NetconfSession session) {
		this.session = session;
	}

	public NetconfSessionFactory(NetConfDeviceRegistry regestry) {
		NetconfManager netconfManager = new NetconfManager();

		Device device = new Device();
		device.setId(regestry.getDeviceID());
		device.setHost(regestry.getDeviceIP());
		device.setPort(regestry.getPort());
		device.setUsername(regestry.getUserName());
		device.setPassword(regestry.getPassword());

		netconfManager.netconfClient.init();
		session = netconfManager.getNetconfSession(device);
		/*
		 * String getConfig = "<get-config><source><candidate/></source></get-config>";
		 * String reply = session.execute(NetconfMessage.getRPCMessage(getConfig)); //
		 * System.out.println(reply);
		 * 
		 * // ======================== getConfig = "<get></get>"; reply =
		 * session.execute(NetconfMessage.getRPCMessage(getConfig));
		 * 
		 * // System.out.println(reply);
		 */
	}


	public static void main(String[] args) {
	}

}
