package com.ipg.horizon.nms.config.commands;

import com.ipg.horizon.nms.config.handler.CommandVisitor;
import com.ipg.horizon.nms.config.netconf.NetconfMessage;
import com.ipg.horizon.nms.config.netconf.NetconfSessionFactory;

public abstract class AbstractRPC {
	String command = "";
	NetconfSessionFactory netconfSessionFactory = null;
	String messageID = null;
	CommandVisitor visitor = null;
	String result="";
	public String getMessageID() {
		return messageID;
	}

	public void setMessageID(String messageID) {
		this.messageID = messageID;
	}

	public AbstractRPC(NetconfSessionFactory cli, String command) {
		this.command = command;
		messageID = "DeviceIP#" + NetconfMessage.msgCounter.get();
		this.netconfSessionFactory = cli;
	}

	public void execute() {
		result=visitor.submit();
	}

	public void visit(CommandVisitor visitor) {
		this.visitor = visitor;
	}
}
