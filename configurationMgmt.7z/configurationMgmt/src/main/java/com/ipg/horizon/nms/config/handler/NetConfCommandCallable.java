package com.ipg.horizon.nms.config.handler;



import java.util.concurrent.Callable;

import com.ipg.horizon.nms.config.commands.AbstractRPC;


public class NetConfCommandCallable implements Callable<String> {
	AbstractRPC command=null;
	 String result="";
	public NetConfCommandCallable(AbstractRPC command) {
		this.command=command;
	}
    @Override
    public String call() throws Exception {
        //return the thread name executing this callable task
    	command.execute();
    	result=command.toString();
        return result;
    }
    
   
}
