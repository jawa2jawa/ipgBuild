package com.ipg.horizon.nms.config.dispach;

import com.ipg.horizon.nms.config.commands.Command;
import com.ipg.horizon.nms.config.handler.CommandResponse;
import com.ipg.horizon.nms.config.handler.ConnectionInfoLock;

public class CommandProducer {

	public CommandProducer() {
	}

	/**
	 * TODO
	 */
	public void sendAcknowledge() {

	}

	/**
	 * TODO
	 */
	public void sendResponse() {

	}

	public CommandResponse addCommand(Command cmd) {
		ConnectionInfoLock lock = new ConnectionInfoLock(cmd.getMessageID() + "");
		synchronized (lock) {
			CommandPool.getInstance().registerLock(cmd.getMessageID(), lock);
			CommandPool.getInstance().commands.add(cmd);
			try {
				/**
				 * send the acknowledge to the client and wait for the response from device
				 */
				// sendAcknowledge();
				wait();
				/**
				 * once getting the response from device send the actual response to the client
				 */
				// sendResponse();
				return CommandPool.getInstance().responseMap.get(cmd.getMessageID());
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return null;
	}
}
