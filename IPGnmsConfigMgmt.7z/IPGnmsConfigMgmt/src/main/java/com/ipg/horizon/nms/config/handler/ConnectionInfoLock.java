package com.ipg.horizon.nms.config.handler;

/**
 * This maintains the MessageID and the Connection information
 * 
 * @author samuel.a
 *
 */
public class ConnectionInfoLock {

	public ConnectionInfoLock(String messageID) {
		this.messageID = messageID;
	}

	public String getMessageID() {
		return messageID;
	}

	String messageID = "";
	
}
