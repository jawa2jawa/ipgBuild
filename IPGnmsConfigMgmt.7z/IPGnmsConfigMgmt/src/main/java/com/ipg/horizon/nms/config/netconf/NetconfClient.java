package com.ipg.horizon.nms.config.netconf;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import javax.annotation.PreDestroy;

import org.apache.sshd.client.ClientFactoryManager;
import org.apache.sshd.client.SshClient;
import org.apache.sshd.client.future.AuthFuture;
import org.apache.sshd.client.future.ConnectFuture;
import org.apache.sshd.client.session.ClientSession;


public class NetconfClient {

	SshClient client;

	public NetconfClient() {
		client = SshClient.setUpDefaultClient();
		client.getProperties().put(ClientFactoryManager.SOCKET_KEEPALIVE, true);
	}

	public void init() {
		client.start();
	}

	public SshClient getClient() {
		return client;
	}
	
	
	public ConnectFuture connect(final Device device) {
		System.out.println(String.format("Connecting to device [%s:%s ]", device.getHost(), device.getPort()));

		ConnectFuture connectFuture;
		try {
			connectFuture = client.connect(device.getUsername(), device.getHost(), device.getPort()).verify(10L, TimeUnit.SECONDS);
		
			connectFuture.addListener(future -> {
			if (!future.isConnected()) {
				throw new RuntimeException("Exception in connecting to " , future.getException());
			}

		});
		
		return connectFuture;

		} catch (IOException e) {
			e.printStackTrace();
			throw new RuntimeException("Exception in connecting to device ", e);
		}
		
		//return  null;
	}

	public NetconfSession getSession(final Device device) {
		System.out.println(String.format("Connecting to device [%s:%s ]", device.getHost(), device.getPort()));
		NetconfSession netconfSession = null;
		try {
			
			final ConnectFuture connectionFuture = client.connect(device.getUsername(), device.getHost(), device.getPort()).verify(10L, TimeUnit.SECONDS);
			connectionFuture.addListener(future -> {
				if (!future.isConnected()) {
					throw new RuntimeException("Exception in connecting to " , future.getException());
				}

			});

			ClientSession session = connectionFuture.getSession();
			session.addPasswordIdentity(device.getPassword());


			final AuthFuture authenticateFuture = session.auth().verify(10L, TimeUnit.SECONDS);
			authenticateFuture.addListener(future1 -> {
				if (!future1.isSuccess()) {
					throw new RuntimeException("Exception in authenticating session" , future1.getException());
				}
			});

			if(authenticateFuture.isSuccess()) {
				netconfSession = new NetconfSession(session);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("Exception in creating session ", e);
		}

		return netconfSession;
	}
	
	
	public NetconfNotificationSession getNotificationSession(final Device device) {
		System.out.println(String.format("Connecting to device [%s:%s ]", device.getHost(), device.getPort()));
		NetconfNotificationSession netconfSession = null;
		try {
			
			final ConnectFuture connectionFuture = client.connect(device.getUsername(), device.getHost(), device.getPort()).verify(10L, TimeUnit.SECONDS);
			connectionFuture.addListener(future -> {
				if (!future.isConnected()) {
					throw new RuntimeException("Exception in connecting to " , future.getException());
				}

			});

			ClientSession session = connectionFuture.getSession();
			session.addPasswordIdentity(device.getPassword());


			final AuthFuture authenticateFuture = session.auth().verify(10L, TimeUnit.SECONDS);
			authenticateFuture.addListener(future1 -> {
				if (!future1.isSuccess()) {
					throw new RuntimeException("Exception in authenticating session" , future1.getException());
				}
			});

			if(authenticateFuture.isSuccess()) {
				netconfSession = new NetconfNotificationSession(session);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("Exception in creating session ", e);
		}

		return netconfSession;
	}



	@PreDestroy
	public void destroy() {
		try {
			client.close();
		} catch (IOException e) {
			e.printStackTrace();
			client = null;
		}
	}
}
