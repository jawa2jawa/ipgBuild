package com.ipg.horizon.nms.config.commands;

import com.ipg.horizon.nms.config.netconf.NetconfSessionFactory;

public class HelloCommand extends Command {

	public HelloCommand(NetconfSessionFactory cli, String command) {
		super(cli, command);
		// TODO Auto-generated constructor stub
	}

	public String toString() {
		// TODO it should be as per required format
		return result;
	}
}
