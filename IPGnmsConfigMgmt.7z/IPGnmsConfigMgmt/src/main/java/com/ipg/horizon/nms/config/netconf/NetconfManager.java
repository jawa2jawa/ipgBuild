package com.ipg.horizon.nms.config.netconf;

import java.io.Serializable;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

import org.apache.sshd.client.future.AuthFuture;
import org.apache.sshd.client.future.ConnectFuture;
import org.apache.sshd.client.session.ClientSession;


public class NetconfManager implements Serializable {

	private static final long serialVersionUID = 1L;
	
	public static Map<Long, ConnectFuture> connectionCache = new ConcurrentHashMap<>();

	public static Map<Long, NetconfSession> sessionCache = new ConcurrentHashMap<>();

	NetconfClient netconfClient=new NetconfClient();
	
	public ConnectFuture getConnection(final Device device) {
		ConnectFuture connectFuture = null;
		connectFuture = connectionCache.get(device.getId());
		if( connectFuture != null && connectFuture.isConnected()) {
			return connectFuture;
		} else {
			connectFuture = netconfClient.connect(device);
			connectionCache.put(device.getId(), connectFuture);
		return connectFuture;
		}	
		
		
		//return netconfClient.connect(device);
	}
	
	public NetconfSession getNetconfSession(final Device device) {
		
		NetconfSession session = null;
		session = sessionCache.get(device.getId());
		if(session == null ) {
			session = netconfClient.getSession(device);;
			sessionCache.put(device.getId(), session);
		}
		//return netconfClient.getSession(device);
		return session;

	}
	
	
	public NetconfNotificationSession getNetconfNotificationSession(final Device device) {
		
		NetconfNotificationSession session = netconfClient.getNotificationSession(device);
		
		return session;

	}


	public NetconfSession getSession(final Device device) {
		System.out.println(String.format("Creating session to device [%s:%s ]", device.getHost(), device.getPort()));
		NetconfSession netconfSession = null;
		try {

			final ConnectFuture connectFuture = getConnection(device);
			ClientSession session = connectFuture.getSession();
			session.addPasswordIdentity(device.getPassword());

			final AuthFuture authenticateFuture = session.auth().verify(10L, TimeUnit.SECONDS);
			authenticateFuture.addListener(future1 -> {
				if (!future1.isSuccess()) {
					throw new RuntimeException("Exception in authenticating session" , future1.getException());
				}
			});

			if(authenticateFuture.isSuccess()) {
				netconfSession = new NetconfSession(session);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("Exception in creating session ", e);
		}

		return netconfSession;
	}


}
