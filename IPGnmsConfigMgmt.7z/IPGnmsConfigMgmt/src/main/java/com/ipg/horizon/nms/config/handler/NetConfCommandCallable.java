package com.ipg.horizon.nms.config.handler;



import java.util.concurrent.Callable;

import com.ipg.horizon.nms.config.commands.Command;


public class NetConfCommandCallable implements Callable<String> {
	Command command=null;
	 String result="";
	public NetConfCommandCallable(Command command) {
		this.command=command;
	}
    @Override
    public String call() throws Exception {
        //return the thread name executing this callable task
    	command.execute();
    	result=command.toString();
        return result;
    }
    
   
}
