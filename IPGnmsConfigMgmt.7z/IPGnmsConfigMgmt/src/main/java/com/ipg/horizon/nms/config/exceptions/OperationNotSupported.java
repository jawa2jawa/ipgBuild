package com.ipg.horizon.nms.config.exceptions;

public class OperationNotSupported extends RuntimeException {
	public OperationNotSupported() {
		super();
	}

	public String toString() {
		return "OperationNotSupported";
	}
}
