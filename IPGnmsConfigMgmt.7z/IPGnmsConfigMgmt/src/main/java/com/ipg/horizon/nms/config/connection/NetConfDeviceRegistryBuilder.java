package com.ipg.horizon.nms.config.connection;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class NetConfDeviceRegistryBuilder {
	Map<String, String> settings = new HashMap<String, String>();
	NetConfDeviceRegistry registry = null;

	public NetConfDeviceRegistryBuilder() {

	}

	public NetConfDeviceRegistry buildRegistery(Map<String, String> settings) {
		this.settings.clear();
		Iterator iterator = settings.keySet().iterator();
		String key = "";
		while (iterator.hasNext()) {
			key = (String) iterator.next();
			settings.put(key, settings.get(key));
		}
		registry = new NetConfDeviceRegistry(settings);
		return registry;
	}

	public class NetConfDeviceRegistry {
		Map<String, String> settings = new HashMap<>();

		NetConfDeviceRegistry(Map<String, String> settings) {
			this.settings = settings;
		}

		public long getDeviceID() {
			return Long.parseLong(settings.get("deviceID"));
		}

		public String getDeviceIP() {
			return settings.get("deviceIP");
		}

		public int getPort() {
			return Integer.parseInt(settings.get("port"));
		}

		public String getUserName() {
			return settings.get("userName");
		}

		public String getPassword() {
			return settings.get("password");
		}
	}
}
