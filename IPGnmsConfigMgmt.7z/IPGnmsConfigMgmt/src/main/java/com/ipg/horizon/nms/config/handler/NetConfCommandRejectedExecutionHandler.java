package com.ipg.horizon.nms.config.handler;

import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;

public class NetConfCommandRejectedExecutionHandler implements RejectedExecutionHandler {

	ThreadPoolExecutor backupExecutor = null;

	public NetConfCommandRejectedExecutionHandler(ThreadPoolExecutor backupExecutor) {
		this.backupExecutor = backupExecutor;
	}

	@Override
	public void rejectedExecution(Runnable worker, ThreadPoolExecutor executor) {
		// TODO Auto-generated method stub
		try {
			// Re-executing with alternateExecutor
			backupExecutor.execute(worker);
		} catch (Exception e) {
			System.out.println("Failure to Re-exicute " + e.getMessage());
		}
	}

}
