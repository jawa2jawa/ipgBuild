package com.ipg.horizon.nms.config.commands;

import com.ipg.horizon.nms.config.netconf.NetconfSessionFactory;
public class CommandFactory {
	NetconfSessionFactory cli = null;

	public CommandFactory(NetconfSessionFactory cli) {
		this.cli = cli;
	}

	public Command getCommand(String command) {
		if (command.contains("<get/>") || command.contains("<get>")) {
			return new GetCommand(cli, command);
		}
		if (command.contains("<get-config>")) {
			return new GetConfigCommand(cli, command);
		}
		if (command.contains("<edit-config>")) {
			return new EditConfigCommand(cli, command);
		}
		if (command.contains("<copy-config>")) {
			return new CopyConfigCommand(cli, command);
		}
		if (command.contains("<delete-config>")) {
			return new DeleteConfig(cli, command);
		}
		if (command.contains("<lock>")) {
			return new LockCommand(cli, command);
		}
		if (command.contains("<unlock>")) {
			return new UnlockCommand(cli, command);
		}
		if (command.contains("<close-session/>") || command.contains("<close-session>")) {
			return new CloseSessionCommand(cli, command);
		}
		if (command.contains("<kill-session>")) {
			return new KillSessionCommand(cli, command);
		}

		return null;
	}
}
