package arK.server;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.HashMap;

public class ClassPathManager {
	public static HashMap<String, Class> classPool = new HashMap<String, Class>();
	public static HashMap<String, String> params = new HashMap<String, String>();
	public static HashMap<String, String> results = new HashMap<String, String>();

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}

	public static void putParam(String key, String value) {
		params.put(key, value);
	}

	/**
	 * It works on the reflection get the package ,class, method and
	 * arguments,signature of the method it store the key method signature and the
	 * result in hashmap It maintains the math that contains the class name and
	 * class Object
	 */
	public static void executeMethod(String className) throws InvocationTargetException, InstantiationException {
		int len = 0;
		int i = 0;
		String tokens[] = new String[2];
		if (className == null) {
			return;
		}
		RequestPareser.parseRequest(className);
		String methodName = RequestPareser.methodName;
		className = RequestPareser.pkg_className;
		try {
			Class cl = Class.forName(className);
			cl = classPool.get(className);
			if (cl == null) {
				cl = Class.forName(className);
				classPool.put(className, cl);
			}
			Method m[] = cl.getDeclaredMethods();
			len = m.length;
			Method calledMethod = null;
			for (i = 0; i < len; i++) {
				if (methodName.equals(m[i].getName())) {
					calledMethod = m[i];
					break;
				}

			}
			invokeMethod(calledMethod);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
		}
	}

	public static void invokeMethod(Method calledMethod) {
		Class types[] = calledMethod.getParameterTypes();
		Parameter args[]=calledMethod.getParameters();
		int len = types.length;
		String name = 	"";
		Object params[]=new Object[calledMethod.getParameterCount()];
		for (int i = 0; i < len; i++) {
			name=args[i].getName();
			System.out.println(name);
		}
	}
}
