package arK.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ArkEngine {

	public static void main(String[] args) throws IOException {
		ServerSocket listenScket = new ServerSocket(6789);
		RequestHandler requestHandler=new RequestHandler();
		while (true) {
			Socket connectionSocket = listenScket.accept();
			connectionSocket.setSoTimeout(10000);
			requestHandler.processRequest(connectionSocket);
		}
	}

}