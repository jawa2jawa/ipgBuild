package arK.server;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.net.Socket;
import java.util.Properties;

import arK.util.ArkUtil;

public class RequestHandler {
	static File base = new File(".");
	static Properties prop = new Properties();
	static String contentType = "";

	public RequestHandler() {
		InputStream input;
		try {
			ClassLoader classLoader = this.getClass().getClassLoader();
	        File file = new File(classLoader.getResource("urlmapper.properties").getFile());
			input = new FileInputStream(file);
			prop.load(input);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void processRequest(Socket connectionSocket) throws IOException {
		String requestMessageLine;
		BufferedReader inFromClient = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream()), 512);
		requestMessageLine = inFromClient.readLine();
		DataOutputStream outToClient = new DataOutputStream(connectionSocket.getOutputStream());
		if (requestMessageLine == null) {
			outToClient.close();

			return;
		}

		if (ArkUtil.getMethodType(requestMessageLine).equals("GET")) {
			doGet(outToClient, requestMessageLine);
		}
		connectionSocket.close();
	}

	public void doGet(DataOutputStream outToClient, String requestMessageLine) {

		String methodStr = requestMessageLine.split(" ")[1].trim();
		if (methodStr.contains("favicon")) {
			contentType = "Connect-Type:image/jpg\r\n";
			prepareDeafultPage(outToClient);
		} else if (methodStr.length() > 1) {
			ArkUtil.loadParameters(requestMessageLine, ClassPathManager.params);
			invokeMethod(outToClient, methodStr);
		} else {
			prepareDeafultPage(outToClient);
		}
	}

	public void prepareBadResponse(DataOutputStream outToClient) {
		try {
			ClassLoader classLoader = this.getClass().getClassLoader();
	        File file = new File(classLoader.getResource("BadRequest.html").getFile());
			int numOfBytes = (int) file.length();
			FileInputStream inFile = new FileInputStream(file);
			byte[] fileBytes = new byte[numOfBytes];
			inFile.read(fileBytes);
			outToClient.writeBytes("HTTP/1.0 200 Document Follows\r\n");
			outToClient.writeBytes("Connect-Length:" + numOfBytes + "\r\n");
			outToClient.writeBytes("\r\n");
			outToClient.write(fileBytes, 0, numOfBytes);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				outToClient.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return;

	}

	public void invokeMethod(DataOutputStream outToClient, String method) {
		try {
			int index=method.indexOf('?');
			if(index==-1) {
				ClassPathManager.executeMethod(prop.getProperty(method));
			}else {
				method=method.substring(0, index);
				ClassPathManager.executeMethod(prop.getProperty(method));
			}
			byte[] fileBytes = ClassPathManager.results.get(RequestPareser.pkg_className).getBytes();
			int numOfBytes = fileBytes.length;
			outToClient.writeBytes("HTTP/1.0 200 Document Follows\r\n");
			outToClient.writeBytes("Connect-Length:" + numOfBytes + "\r\n");
			outToClient.writeBytes("\r\n");
			outToClient.write(fileBytes, 0, numOfBytes);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				outToClient.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
	}

	public void prepareDeafultPage(DataOutputStream outToClient) {
		try {
			ClassLoader classLoader = this.getClass().getClassLoader();
	        File file = new File(classLoader.getResource("index.html").getFile());
			int numOfBytes = (int) file.length();
			FileInputStream inFile = new FileInputStream(file);
			byte[] fileBytes = new byte[numOfBytes];
			inFile.read(fileBytes);
			outToClient.writeBytes("HTTP/1.0 200 Document Follows\r\n");
			if (contentType.trim().length() > 0) {
				outToClient.writeBytes(contentType.trim());
			}
			outToClient.writeBytes("Connect-Length:" + numOfBytes + "\r\n");
			outToClient.writeBytes("\r\n");
			outToClient.write(fileBytes, 0, numOfBytes);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				outToClient.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
