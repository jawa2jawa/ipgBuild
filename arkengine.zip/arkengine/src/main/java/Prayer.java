
public class Prayer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Jesus is Lord:Romans-10:9");
	}

}
