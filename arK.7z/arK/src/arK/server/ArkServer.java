package arK.server;


import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Properties;
import java.util.StringTokenizer;

import arK.server.requesthandler.RequestHandler;
import arK.util.ArkUtil;


public class ArkServer {
	public static void main(String[] args) throws IOException {
		Properties prop = new Properties();
		InputStream input = new FileInputStream("C:\\workSpace\\arK\\resource\\urlmapper.properties");
		prop.load(input);
		RequestHandler rh=new RequestHandler();
		ServerSocket listenScket = new ServerSocket(6789);
		while (true) {
			String requestMessageLine;
			String fileName;
			Socket connectionSocket = listenScket.accept();
			BufferedReader inFromClient = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream()));
			DataOutputStream outToClient = new DataOutputStream(connectionSocket.getOutputStream());
			requestMessageLine = inFromClient.readLine();
			String request=requestMessageLine.split(" ")[1];
			
			ArkUtil.loadParameters(requestMessageLine, ClassPathManager.params);
			
			StringTokenizer tokenizedLine = new StringTokenizer(requestMessageLine);
			String tokens[]=requestMessageLine.split("/");
			if (ArkUtil.getMethodType(requestMessageLine).equals("GET")) {
				fileName = tokenizedLine.nextToken();
				if (fileName.startsWith("/")) {
					fileName = fileName.substring(1);
				}

				ClassPathManager.executeMethod(prop.getProperty(requestMessageLine.split(" ")[1].trim()));
				
				fileName = "C:\\workSpace\\arK\\FirstRequest.html";
				File file = new File(fileName);
				int numOfBytes = (int) file.length();
				FileInputStream inFile = new FileInputStream(fileName);
				byte[] fileBytes = new byte[numOfBytes];
				inFile.read(fileBytes);
				outToClient.writeBytes("HTTP/1.0 200 Document Follows\r\n");
				if (fileName.endsWith(".jpg")) {
					outToClient.writeBytes("Connect-Type:image/jpeg\r\n");
				}
				if (fileName.endsWith(".gif")) {
					outToClient.writeBytes("Connect-Type:image/gif\r=n");
				}
				outToClient.writeBytes("Connect-Length:" + numOfBytes + "\r\n");
				outToClient.writeBytes("\r\n");
				outToClient.write(fileBytes, 0, numOfBytes);
				connectionSocket.close();
			} else {
				System.out.println("Bad Request Message");
			}
		}
	}
}