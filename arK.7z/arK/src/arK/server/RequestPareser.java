package arK.server;

public class RequestPareser {


	static String pkg_className = "";
	static String methodName = "";

	public static void parseRequest(String className) {
		int len = className.length();
		int i = 0;
		for (i = len - 1; i >= 0; i--) {
			if (className.charAt(i) == '.') {
				break;
			}
		}
		methodName = className.substring(i + 1);
		pkg_className = className.substring(0, i);
	}

}
