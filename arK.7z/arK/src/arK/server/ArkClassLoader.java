package arK.server;

public class ArkClassLoader extends ClassLoader{

}
