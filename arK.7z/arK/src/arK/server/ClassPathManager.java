package arK.server;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;

import arK.util.ArkUtil;

public class ClassPathManager {
	public static HashMap<String, Class> classPool = new HashMap<String, Class>();
	public static HashMap<String, String> params = new HashMap<String, String>();
	public static HashMap<String, String> results = new HashMap<String, String>();

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		executeMethod("");
	}

	public static void putParam(String key, String value) {
		params.put(key, value);
	}

	/**
	 * It works on the reflection get the package ,class, method and
	 * arguments,signature of the method it store the key method signature and the
	 * result in hashmap It maintains the math that contains the class name and
	 * class Object
	 */
	public static void executeMethod(String className) {
		int len = 0;
		int i = 0;
		String tokens[]=new String[2];
		RequestPareser.parseRequest(className);
		PrintWriter out=null;
		String methodName = RequestPareser.methodName;
		className =RequestPareser.pkg_className;
		try {
			 out=new PrintWriter("C:\\workSpace\\arK\\FirstRequest.html");
			Class cl = Class.forName(className);
			cl = classPool.get(className);
			if (cl == null) {
				cl = Class.forName(className);
				classPool.put(className, cl);
			}
			Method m[] = cl.getDeclaredMethods();
			len = m.length;
			for ( i = 0; i < len; i++) {
				if (methodName.equals(m[i].getName())) {
					Object retVal = m[i].invoke(cl.newInstance(), null);
					results.put(className, retVal.toString());
					out.println(retVal);
				}
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			out.close();
		}
	}
}
