package arK.server;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;

public class ClassPathManager {
	public static HashMap<String, Class> classPool = new HashMap<String, Class>();
	public static HashMap<String, String> params = new HashMap<String, String>();
	public static HashMap<String, String> results = new HashMap<String, String>();

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		executeMethod("","org.ipg.nms", "FTPUtil", "uploadFile");
	}

	public static void putParam(String key, String value) {
		params.put(key, value);
	}

	/**
	 * It works on the reflection get the package ,class, method and
	 * arguments,signature of the method it store the key method signature and the
	 * result in hashmap It maintains the math that contains the class name and
	 * class Object
	 */
	public static void executeMethod(String url,String pkg, String className, String method) {
		try {
			Class cl = Class.forName("org.ipg.nms.FTPUtil");
			cl = classPool.get("org.ipg.nms.FTPUtil");
			if (cl == null) {
				cl = Class.forName("org.ipg.nms.FTPUtil");
				classPool.put("org.ipg.nms.FTPUtil", cl);
			}
			Method m[] = cl.getDeclaredMethods();
			int len = m.length;
			for (int i = 0; i < len; i++) {
				if (method.equals(m[i].getName())) {
					Object retVal = m[i].invoke(cl.newInstance(), null);
					results.put(url, retVal.toString());
					System.out.println(retVal);
				}
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
