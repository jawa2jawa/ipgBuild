package arK.util;

import java.util.HashMap;

public class ArkUtil {
	public static void populateMap(String request,HashMap<String, String> paramMap) {
		int firstIndex=request.indexOf("?");
		int lastIndex=request.indexOf("HTTP");
		request=request.substring(firstIndex, lastIndex);
		String tokes[]=request.split("&");
		int len=tokes.length;
		String data[]=new String[2];
		for(int i=0;i<len;i++) {
			data=tokes[i].split("=");
			paramMap.put(data[0], data[1]);
		}
	}
	public static String getMethodType(String request) {
		String tokens[]=request.split("/");
		return tokens[0].trim();
	}
	public static String getApplicationContextName(String request) {
		String tokens[]=request.split("/");
		return tokens[1].trim();
	}
}