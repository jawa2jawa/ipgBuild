package org.ipg.nms.action;

import org.ipg.horizon.nms.audit.utill.AuditUtill;

public class AuditAction{

	private String username;
	 
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	// all struts logic here
	public String execute() {
		System.out.println("INTEGRATED....."+AuditUtill.generateFileName(getClass()));
		return "SUCCESS";

	}
}