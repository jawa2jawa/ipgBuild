package org.ipg.nms.action;

import java.util.List;

import javax.xml.ws.Response;
/**
 * TODO not yet started implementing
 * @author samuel.a
 *
 */
public class AuditLogAction {
	public Response getAuditLog(Integer page, Integer size, List<String> sort) {
		return null;
	}
}
