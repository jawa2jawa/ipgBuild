package org.ipg.nms.action;

import org.ipg.horizon.nms.audit.service.AuditLogService;
import org.ipg.horizon.nms.audit.service.IAuditLogService;

public class AuditArchiveAction {
	IAuditLogService iAuditLogService=new AuditLogService();
	// all struts logic here
		public String execute() {
			
			System.out.println("TRIGGERING ");
			try {
				iAuditLogService.archiveAudit();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return "SUCCESS";

		}
}
