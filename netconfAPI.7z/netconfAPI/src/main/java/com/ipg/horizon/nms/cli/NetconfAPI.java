package com.ipg.horizon.nms.cli;

import com.ipg.horizon.nms.cli.NetConfDeviceRegistryBuilder.NetConfDeviceRegistry;
import com.ipg.horizon.nms.netconf.NetconfSessionFactory;

public class NetconfAPI {
	NetconfSessionFactory netconfSessionFactory = null;

	public NetconfAPI(NetConfDeviceRegistry regestry) {
		// TODO Auto-generated constructor stub
		netconfSessionFactory = new NetconfSessionFactory(regestry);
	}

	public String execute(String cmd) {
		return netconfSessionFactory.getSession().execute(cmd);
	}

}
