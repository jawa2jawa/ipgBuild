package com.ipg.horizon.nms.netconf;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicInteger;

public class NetconfMessage {
	
	
	final static AtomicInteger msgCounter = new AtomicInteger();
	
	public static String defaultHelloRPC() {
		ArrayList<String> defaultCap = getDefaultClientCapabilities();
		return createHelloRPC(defaultCap);
	}

	public static ArrayList<String> getDefaultClientCapabilities() {
		ArrayList<String> defaultCap = new ArrayList<String>();
		defaultCap.add("urn:ietf:params:netconf:base:1.0");
		/*defaultCap.add("urn:ietf:params:xml:ns:netconf:base:1.0#candidate");
		defaultCap.add("urn:ietf:params:xml:ns:netconf:base:1.0#confirmed-commit");
		defaultCap.add("urn:ietf:params:xml:ns:netconf:base:1.0#validate");
		defaultCap.add("urn:ietf:params:xml:ns:netconf:base:1.0#url?protocol=http,ftp,file");*/
		return defaultCap;
	}


	public static String createHelloRPC(ArrayList<String> capabilities) {
		StringBuffer helloRPC = new StringBuffer();
		//helloRPC.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
		helloRPC.append("<hello>\n");
		helloRPC.append("<capabilities>\n");
		Iterator<String> capIter = capabilities.iterator();
		while(capIter.hasNext()) {
			String capability = (String)capIter.next();
			helloRPC.append("<capability>" + capability + "</capability>\n");
		}
		helloRPC.append("</capabilities>\n");
		helloRPC.append("</hello>\n");
		helloRPC.append("]]>]]>\n");
		return helloRPC.toString();
	}
	
	
	public static String getRPCMessage(String rpcContent) {
		rpcContent = rpcContent.trim();
		if (!rpcContent.startsWith("<rpc>") && !rpcContent.equals("<rpc/>")) {
			if (rpcContent.startsWith("<"))
				rpcContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n <rpc message-id=\""+ msgCounter.getAndIncrement() + "\" xmlns=\"urn:ietf:params:xml:ns:netconf:base:1.0\">" + rpcContent + "</rpc>"; 
			else
				rpcContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n <rpc message-id=\""+ msgCounter.getAndIncrement() + "\" xmlns=\"urn:ietf:params:xml:ns:netconf:base:1.0\">" + "<" + rpcContent + "/>" + "</rpc>"; 
		}
		rpcContent += "]]>]]>";

		return rpcContent;
	}
	
	
	public static String createSubscription() {
		StringBuffer subscription = new StringBuffer();
		subscription.append("<rpc message-id=\""+ msgCounter.incrementAndGet() + "\" xmlns=\"urn:ietf:params:xml:ns:netconf:base:1.0\">\n");
		subscription.append("<create-subscription xmlns=\"urn:ietf:params:xml:ns:netconf:notification:1.0\">\n");
		subscription.append("<stream>NETCONF</stream>\n");
		subscription.append("</create-subscription>\n");
		subscription.append("</rpc>\n");
		subscription.append("]]>]]>");
		return subscription.toString();
	}


}
