package com.ipg.horizon.nms.exec;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CommandExecutor {
	ExecutorService executor = null;

	public CommandExecutor() {

		// Get ExecutorService from Executors utility class, thread pool size is 10
		executor = Executors.newFixedThreadPool(10);


	}

	public String submit(String commandStr) {
		String result = "";
		NetConfCommandCallable callable = null;
		try {
			return executor.submit(callable).get();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
}
