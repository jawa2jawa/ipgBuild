package com.ipg.horizon.nms.exec;

import java.util.HashMap;
import java.util.Map;

public class CommandHandler {
	Map<String, CommandExecutor> deviceCliPool = new HashMap<String, CommandExecutor>();
	/**
	 * It has to have all the device info and creates the NetConfDeviceRegistryBuilder and creates the NetConfDeviceRegistry
	 * populate the deviceCliPool for each device
	 */
	public CommandHandler() {

	}

	public void hadleCommand(String deviceIP, String command) {
		deviceCliPool.get(deviceIP).submit(command);
	}
}
