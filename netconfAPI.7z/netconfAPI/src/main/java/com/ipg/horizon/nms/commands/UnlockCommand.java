package com.ipg.horizon.nms.commands;

import com.ipg.horizon.nms.netconf.NetconfSessionFactory;

public class UnlockCommand extends Command {

	public UnlockCommand(NetconfSessionFactory cli, String command) {
		super(cli, command);
		// TODO Auto-generated constructor stub
	}

	public String toString() {
		// TODO it should be as per required format
		return result;
	}
}
