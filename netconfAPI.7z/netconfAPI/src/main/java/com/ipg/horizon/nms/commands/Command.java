package com.ipg.horizon.nms.commands;

import com.ipg.horizon.nms.netconf.NetconfSessionFactory;

public abstract class Command {
	String command = "";
	NetconfSessionFactory netconfSessionFactory = null;
	String result="";
	public Command(NetconfSessionFactory cli, String command) {
		this.command = command;
		this.netconfSessionFactory = cli;
	}

	public void execute() {
		result=netconfSessionFactory.getSession().execute(command);
	}

}
