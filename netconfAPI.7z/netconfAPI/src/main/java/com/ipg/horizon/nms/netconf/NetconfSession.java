package com.ipg.horizon.nms.netconf;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Serializable;
import java.nio.charset.StandardCharsets;
import java.util.EnumSet;
import java.util.concurrent.TimeUnit;

import org.apache.sshd.client.channel.ClientChannel;
import org.apache.sshd.client.channel.ClientChannelEvent;
import org.apache.sshd.client.session.ClientSession;

public class NetconfSession implements Serializable{

	private static final long serialVersionUID = 1L;
	final static String NETCONF_SUBSYSTEM = "netconf";
	final static String NETCONF_EOM = "]]>]]>";

	
	ClientSession session;
	ClientChannel channel;
	BufferedWriter writer;
	BufferedReader reader;
	
	String capablities;


	public NetconfSession(ClientSession session) {		
		this.session = session;
		init();
	}


	public void init() {
		try {
			channel = this.session.createSubsystemChannel(NETCONF_SUBSYSTEM);
			channel.open().await();
			writer = new BufferedWriter(new OutputStreamWriter(channel.getInvertedIn()));
			reader = new BufferedReader(new InputStreamReader(channel.getInvertedOut()));	
			
			capablities = execute(NetconfMessage.defaultHelloRPC());

		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("Exception in initializing netconf channel ", e);
		}
		
	}


	public String  execute(String message) {
		String result = null;
		
		System.out.println("session.getSessionId() = " + new String(session.getSessionId(), StandardCharsets.ISO_8859_1));
		try {
			
			System.out.println("Writing....");
			System.out.println(message);
			write(message);
			

			channel.waitFor(EnumSet.of(ClientChannelEvent.CLOSED), TimeUnit.SECONDS.toMillis(1L));

			result = read();
			
			System.out.println("Reply....");
			System.out.println(result);

		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("Exception in executing  netconf message ", e);
		}/*finally {
			try {
				reader.close();
				writer.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}*/
		return result;
	}


	private void write(String message) throws IOException {
		writer.write(message);
		writer.flush();
	}

	private String read() throws IOException {
		String message = "";
		
		InputStream io = channel.getInvertedOut();
		while (true) {
			byte [] buffer = new byte[1024];
			io.read(buffer, 0, buffer.length);
			
			String mes = new String(buffer);
			
			message += mes;
			
			if(message.contains(NETCONF_EOM)) {
				break;
			}
		}

		return message;
	}

}
