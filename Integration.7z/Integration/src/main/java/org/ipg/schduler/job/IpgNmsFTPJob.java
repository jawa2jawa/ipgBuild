package org.ipg.schduler.job;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

public class IpgNmsFTPJob implements Job {

    ArrayBlockingQueue ftpQueue = null;


    public IpgNmsFTPJob() {
        Logger.getLogger(IpgNmsFTPJob.class.getName()).log(Level.SEVERE, null, "IpgNmsFTPJob");
    }

    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        /**
         * CALL to FTP uplaod
         */
         Logger.getLogger(IpgNmsFTPJob.class.getName()).log(Level.SEVERE, null, "Inside the JOB");
        System.out.println("job " + context.getJobDetail().getKey() + context.getNextFireTime().toString());
    }
}
