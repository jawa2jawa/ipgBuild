package org.ipg.schduler.job;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

public class IpgNmsDBJob implements Job {

    ArrayBlockingQueue dbQueue = null;
    

    public IpgNmsDBJob() {
         Logger.getLogger(IpgNmsDBJob.class.getName()).log(Level.SEVERE, null, "IpgNmsDBJob");
    }

    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        Logger.getLogger(IpgNmsDBJob.class.getName()).log(Level.SEVERE, null, "IpgNmsDBJob");
        System.out.println("job " + context.getJobDetail().getKey() + context.getNextFireTime().toString());
    }
}
