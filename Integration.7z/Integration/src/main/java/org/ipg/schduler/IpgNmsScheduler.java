package org.ipg.schduler;

import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.ipg.nms.listener.IpgNmsContextListener;
import org.ipg.schduler.job.IpgNmsDBJob;
import org.ipg.schduler.job.IpgNmsFTPJob;

import org.quartz.CronScheduleBuilder;
import org.quartz.CronTrigger;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SchedulerFactory;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;

public class IpgNmsScheduler {

    /**
     * @param args
     */
    public static void main(String[] args) {
        IpgNmsScheduler obj = new IpgNmsScheduler();
        obj.runIpgNmsScheduler();
    }

    public void runIpgNmsScheduler() {
        try {
            Logger.getLogger(IpgNmsContextListener.class.getName()).log(Level.SEVERE, null, "runIpgNmsScheduler..");
            // First we must get a reference to a scheduler
            SchedulerFactory sf = new StdSchedulerFactory();
            Scheduler sched = sf.getScheduler();
            Date ft = null;

            /**
             * ftpJob Using CronTrigger
             */
            JobDetail ftpJob = JobBuilder.newJob(IpgNmsFTPJob.class).withIdentity("FTP-JOB", "device").build();

            // run every 1 second
            CronTrigger ftpTrigger = TriggerBuilder.newTrigger().withIdentity("FTP_TRIGGER", "device")
                    .withSchedule(CronScheduleBuilder.cronSchedule("0/10 * * * * ?")).build();

            ft = sched.scheduleJob(ftpJob, ftpTrigger);
            sched.start();

            /**
             * dbJob Using CronTrigger
             */
            JobDetail dbJob = JobBuilder.newJob(IpgNmsDBJob.class).withIdentity("DB-JOB", "NMS").build();

            // run every 1 second
            CronTrigger dbTrigger = TriggerBuilder.newTrigger().withIdentity("DB_TRIGGER", "NMS")
                    .withSchedule(CronScheduleBuilder.cronSchedule("0/10 * * * * ?")).build();

            ft = sched.scheduleJob(dbJob, dbTrigger);
            sched.start();

        } catch (SchedulerException e) {
            e.printStackTrace();
        }
    }
}
