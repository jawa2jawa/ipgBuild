package org.ipg.nms.listener;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
import org.ipg.schduler.IpgNmsScheduler;
import org.ipg.schduler.job.IpgNmsFTPJob;



@WebListener
public class IpgNmsContextListener implements ServletContextListener {

    public void contextInitialized(ServletContextEvent servletContextEvent) {
    	ServletContext ctx = servletContextEvent.getServletContext();
    	 Logger.getLogger(IpgNmsContextListener.class.getName()).log(Level.SEVERE, null, "Quartz Initiating..");
    	IpgNmsScheduler obj = new IpgNmsScheduler();
		obj.runIpgNmsScheduler();
    	
    	
    }

    public void contextDestroyed(ServletContextEvent servletContextEvent) {
    	ServletContext ctx = servletContextEvent.getServletContext();
    	
    }
	
}
