package org.ipg.nms.listener;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Enumeration;
import javax.servlet.ServletRequest;
import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;
import javax.servlet.annotation.WebListener;

@WebListener
public class IpgNmsRequestListener implements ServletRequestListener {


    public void requestDestroyed(ServletRequestEvent servletRequestEvent) {
        ServletRequest servletRequest = servletRequestEvent.getServletRequest();
        System.out.println("ServletRequest destroyed. Remote IP=" + servletRequest.getRemoteAddr());
    }

    public void requestInitialized(ServletRequestEvent servletRequestEvent) {
        ServletRequest servletRequest = servletRequestEvent.getServletRequest();
        System.out.println("ServletRequest initialized. Remote IP=" + servletRequest.getRemoteAddr());
        Enumeration requestparts = servletRequest.getAttributeNames();
        while (requestparts.hasMoreElements()) {
            String name = (String) requestparts.nextElement();
        }        
        System.out.println("ServletRequest initialized. Remote IP=" + servletRequest.getAttributeNames());
    }

}
